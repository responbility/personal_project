---
name: Bug report 버그 제보
about: Report Bugs!
title: ''
labels: ''
assignees: ''

---

Requirements (필요):
- What happens... (버그 내용)
- When I do something... (상황, 조건)
- My device is... (기종)

Additional (선택):
- Screenshots! (스크린샷!)
- Cheer-Up message for lonesome developer
  (외로운 1인 개발자를 위한 응원 메세지)
