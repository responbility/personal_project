---
name: Balance Feedback 밸런싱
about: Feedback about Balance
title: ''
labels: ''
assignees: ''

---

Note: The Heretic is a high-difficulty class, so playing him makes you feel harder then original SPD
(참고: 이단자는 높은 난이도의 영웅으로 만들어졌으며, 때문에 원본 녹픽던보다 더 어렵게 느껴질 수 있음)
